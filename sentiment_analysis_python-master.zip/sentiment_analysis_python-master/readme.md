## README

### Documentation

For documentation, check out the blog post about this code [here](http://andybromberg.com/sentiment-analysis-python).

### Note

Due to the fact that I developed this on Windows, there might be issues reading the polarity data files by line using the code I provided (because of inconsistent line break characters). If this comes up, please [email me](mailto:hi@andybromberg.com)!